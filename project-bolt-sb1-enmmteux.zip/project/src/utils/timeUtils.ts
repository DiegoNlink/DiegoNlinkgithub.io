export const formatTimeAgo = (timestamp: string, t: (key: string) => string): string => {
  const now = new Date();
  const postTime = new Date(timestamp);
  const diffInMinutes = Math.floor((now.getTime() - postTime.getTime()) / (1000 * 60));

  if (diffInMinutes < 1) {
    return t('post.justNow');
  } else if (diffInMinutes < 60) {
    return `${diffInMinutes} ${t('post.minutesAgo')}`;
  } else if (diffInMinutes < 1440) {
    const hours = Math.floor(diffInMinutes / 60);
    return `${hours} ${t('post.hoursAgo')}`;
  } else {
    const days = Math.floor(diffInMinutes / 1440);
    return `${days} ${t('post.daysAgo')}`;
  }
};

export const generateId = (): string => {
  return Math.random().toString(36).substr(2, 9);
};