import React, { useState } from 'react';
import { Home, Search, Users, MessageCircle, Bell, Plus, User, TrendingUp, LogOut, Play, Sparkles } from 'lucide-react';
import { useLanguage } from './hooks/useLanguage';
import { useAuth } from './hooks/useAuth';
import { LanguageSelector } from './components/LanguageSelector';
import { PostCard } from './components/PostCard';
import { CreatePostModal } from './components/CreatePostModal';
import { AuthModal } from './components/AuthModal';
import { VideoSection } from './components/VideoSection';
import { CreateVideoModal } from './components/CreateVideoModal';
import { AIEnhanceModal } from './components/AIEnhanceModal';
import { Post, Comment, TrendingTopic, Community, Video } from './types';
import { generateId, formatTimeAgo } from './utils/timeUtils';

function App() {
  const { t } = useLanguage();
  const { currentUser, isAuthenticated, login, register, logout } = useAuth();
  const [currentView, setCurrentView] = useState('home');
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [showCreateVideo, setShowCreateVideo] = useState(false);
  const [showAIEnhance, setShowAIEnhance] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);

  const [posts, setPosts] = useState<Post[]>([
    {
      id: '1',
      user: { 
        id: '1',
        name: 'Alex Rodriguez', 
        username: 'alexr',
        avatar: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=150', 
        verified: true,
        followers: 1250,
        following: 890
      },
      content: 'Just launched my new project! Excited to share it with the MS6 community. The future of social networking is here! 🚀\n\nWhat do you think about the new features?',
      image: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=600',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      likes: 47,
      comments: [
        {
          id: 'c1',
          user: {
            id: '2',
            name: 'Sarah Chen',
            username: 'sarahc',
            avatar: 'https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=150',
            verified: false,
            followers: 500,
            following: 300
          },
          content: 'This looks amazing! Can\'t wait to try it out.',
          timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
          likes: 5,
          isLiked: false
        }
      ],
      shares: 8,
      isLiked: false,
      isShared: false,
      type: 'image'
    },
    {
      id: '2',
      user: { 
        id: '2',
        name: 'Sarah Chen', 
        username: 'sarahc',
        avatar: 'https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=150', 
        verified: false,
        followers: 500,
        following: 300
      },
      content: 'Beautiful sunset from my hiking trip today. Nature never fails to amaze me! 🌅\n\nThere\'s something magical about watching the day end from a mountain peak.',
      image: 'https://images.pexels.com/photos/1287145/pexels-photo-1287145.jpeg?auto=compress&cs=tinysrgb&w=600',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
      likes: 89,
      comments: [],
      shares: 15,
      isLiked: true,
      isShared: false,
      type: 'image'
    },
    {
      id: '3',
      user: { 
        id: '3',
        name: 'Marcus Thompson', 
        username: 'marcust',
        avatar: 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=150', 
        verified: true,
        followers: 2100,
        following: 450
      },
      content: 'Working on some exciting new features for our platform. Can\'t wait to show you all what we\'ve been building! Stay tuned for updates.\n\n#MS6 #Innovation #TechLife',
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
      likes: 156,
      comments: [],
      shares: 28,
      isLiked: false,
      isShared: true,
      type: 'text'
    }
  ]);

  const trendingTopics: TrendingTopic[] = [
    { topic: '#MS6Launch', posts: '12.5K', growth: 15 },
    { topic: '#TechInnovation', posts: '8.7K', growth: 8 },
    { topic: '#SocialMedia', posts: '6.2K', growth: -2 },
    { topic: '#FutureOfTech', posts: '4.1K', growth: 12 }
  ];

  const suggestedCommunities: Community[] = [
    {
      id: '1',
      name: 'Tech Innovators',
      description: 'Latest in technology and innovation',
      members: 125000,
      icon: '💻',
      color: 'from-blue-500 to-purple-600'
    },
    {
      id: '2',
      name: 'Digital Creators',
      description: 'For content creators and digital artists',
      members: 89000,
      icon: '🎨',
      color: 'from-green-500 to-emerald-600'
    }
  ];

  const handleLike = (postId: string) => {
    if (!isAuthenticated) {
      setShowAuthModal(true);
      return;
    }

    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          isLiked: !post.isLiked,
          likes: post.isLiked ? post.likes - 1 : post.likes + 1
        };
      }
      return post;
    }));
  };

  const handleComment = (postId: string, content: string) => {
    if (!isAuthenticated || !currentUser) {
      setShowAuthModal(true);
      return;
    }

    const newComment: Comment = {
      id: generateId(),
      user: currentUser,
      content,
      timestamp: new Date().toISOString(),
      likes: 0,
      isLiked: false
    };

    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          comments: [...post.comments, newComment]
        };
      }
      return post;
    }));
  };

  const handleShare = (postId: string) => {
    if (!isAuthenticated) {
      setShowAuthModal(true);
      return;
    }

    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          isShared: !post.isShared,
          shares: post.isShared ? post.shares - 1 : post.shares + 1
        };
      }
      return post;
    }));
  };

  const handleCreatePost = (content: string, image?: string) => {
    if (!isAuthenticated || !currentUser) {
      setShowAuthModal(true);
      return;
    }

    const newPost: Post = {
      id: generateId(),
      user: currentUser,
      content,
      image,
      timestamp: new Date().toISOString(),
      likes: 0,
      comments: [],
      shares: 0,
      isLiked: false,
      isShared: false,
      type: image ? 'image' : 'text'
    };

    setPosts([newPost, ...posts]);
  };

  const handleCreateVideo = (title: string, description: string, videoUrl: string, tags: string[]) => {
    if (!isAuthenticated || !currentUser) {
      setShowAuthModal(true);
      return;
    }

    const newVideoPost: Post = {
      id: generateId(),
      user: currentUser,
      content: `${title}\n\n${description}\n\n${tags.join(' ')}`,
      video: videoUrl,
      timestamp: new Date().toISOString(),
      likes: 0,
      comments: [],
      shares: 0,
      isLiked: false,
      isShared: false,
      type: 'video'
    };

    setPosts([newVideoPost, ...posts]);
    setShowCreateVideo(false);
  };

  const handleLogin = (email: string, password: string): boolean => {
    return login(email, password);
  };

  const handleRegister = (userData: any): boolean => {
    return register(userData);
  };

  const handleCreatePostClick = () => {
    if (!isAuthenticated) {
      setShowAuthModal(true);
      return;
    }
    setShowCreatePost(true);
  };

  const handleCreateVideoClick = () => {
    if (!isAuthenticated) {
      setShowAuthModal(true);
      return;
    }
    setShowCreateVideo(true);
  };

  const handleAIEnhanceClick = () => {
    if (!isAuthenticated) {
      setShowAuthModal(true);
      return;
    }
    setShowAIEnhance(true);
  };

  const Navigation = () => (
    <nav className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-lg border-b border-gray-200 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-emerald-800 to-teal-700 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">MS6</span>
              </div>
              <span className="text-xl font-bold text-gray-900">MS6</span>
            </div>
            <div className="hidden md:flex space-x-6">
              <button
                onClick={() => setCurrentView('home')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all ${
                  currentView === 'home' ? 'bg-emerald-50 text-emerald-800' : 'text-gray-600 hover:text-emerald-700'
                }`}
              >
                <Home size={20} />
                <span className="font-medium">{t('nav.home')}</span>
              </button>
              <button
                onClick={() => setCurrentView('videos')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all ${
                  currentView === 'videos' ? 'bg-emerald-50 text-emerald-800' : 'text-gray-600 hover:text-emerald-700'
                }`}
              >
                <Play size={20} />
                <span className="font-medium">{t('nav.videos')}</span>
              </button>
              <button
                onClick={() => setCurrentView('discover')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all ${
                  currentView === 'discover' ? 'bg-emerald-50 text-emerald-800' : 'text-gray-600 hover:text-emerald-700'
                }`}
              >
                <Search size={20} />
                <span className="font-medium">{t('nav.discover')}</span>
              </button>
              <button
                onClick={() => setCurrentView('communities')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all ${
                  currentView === 'communities' ? 'bg-emerald-50 text-emerald-800' : 'text-gray-600 hover:text-emerald-700'
                }`}
              >
                <Users size={20} />
                <span className="font-medium">{t('nav.communities')}</span>
              </button>
            </div>
          </div>
          
          <div className="flex-1 max-w-md mx-8 hidden md:block">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder={t('nav.search')}
                className="w-full pl-10 pr-4 py-2 bg-gray-100 border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              />
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <LanguageSelector />
            {isAuthenticated ? (
              <>
                <button 
                  onClick={handleAIEnhanceClick}
                  className="p-2 text-gray-600 hover:text-purple-700 hover:bg-purple-50 rounded-full transition-all relative group"
                  title="AI 4K Enhancement"
                >
                  <Sparkles size={22} />
                  <span className="absolute -top-1 -right-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">AI</span>
                </button>
                <button className="p-2 text-gray-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-full transition-all">
                  <MessageCircle size={22} />
                </button>
                <button className="p-2 text-gray-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-full transition-all relative">
                  <Bell size={22} />
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">3</span>
                </button>
                <div className="flex items-center space-x-3">
                  <img 
                    src={currentUser?.avatar} 
                    alt={currentUser?.name}
                    className="w-8 h-8 rounded-full object-cover cursor-pointer hover:scale-105 transition-transform"
                  />
                  <button
                    onClick={logout}
                    className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-full transition-all"
                    title={t('auth.logout')}
                  >
                    <LogOut size={20} />
                  </button>
                </div>
              </>
            ) : (
              <button
                onClick={() => setShowAuthModal(true)}
                className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-4 py-2 rounded-full font-medium hover:shadow-lg transition-all"
              >
                {t('auth.login')}
              </button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );

  const Sidebar = () => (
    <div className="hidden lg:block w-80 space-y-6">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
          <TrendingUp size={20} className="mr-2 text-emerald-600" />
          {t('sidebar.trending')}
        </h3>
        <div className="space-y-3">
          {trendingTopics.map((topic, index) => (
            <div key={index} className="flex justify-between items-center p-3 hover:bg-gray-50 rounded-lg cursor-pointer transition-colors">
              <div>
                <p className="font-medium text-emerald-700">{topic.topic}</p>
                <p className="text-sm text-gray-500">{topic.posts} {t('sidebar.posts')}</p>
              </div>
              <div className={`text-xs px-2 py-1 rounded-full ${
                topic.growth > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}>
                {topic.growth > 0 ? '+' : ''}{topic.growth}%
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
          <Users size={20} className="mr-2 text-emerald-600" />
          {t('sidebar.suggestedCommunities')}
        </h3>
        <div className="space-y-4">
          {suggestedCommunities.map((community) => (
            <div key={community.id} className="flex items-center space-x-3 p-3 hover:bg-gray-50 rounded-lg cursor-pointer transition-colors">
              <div className={`w-10 h-10 bg-gradient-to-br ${community.color} rounded-lg flex items-center justify-center`}>
                <span className="text-xl">{community.icon}</span>
              </div>
              <div className="flex-1">
                <p className="font-medium">{community.name}</p>
                <p className="text-sm text-gray-500">{community.members.toLocaleString()} {t('sidebar.members')}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* AI Enhancement Quick Access */}
      <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl shadow-sm border border-purple-100 p-6">
        <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
          <Sparkles size={20} className="mr-2 text-purple-600" />
          AI Enhancement
        </h3>
        <p className="text-sm text-gray-600 mb-4">
          Transform your images to stunning 4K quality with our advanced AI technology.
        </p>
        <button
          onClick={handleAIEnhanceClick}
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-2 px-4 rounded-lg font-medium hover:shadow-lg transition-all"
        >
          Enhance to 4K
        </button>
      </div>
    </div>
  );

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50">
        <Navigation />
        <AuthModal 
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
          onLogin={handleLogin}
          onRegister={handleRegister}
        />
        
        <div className="pt-20 flex items-center justify-center min-h-screen">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="mb-8">
              <div className="w-24 h-24 bg-gradient-to-br from-emerald-800 to-teal-700 rounded-3xl flex items-center justify-center mx-auto mb-6">
                <span className="text-white font-bold text-3xl">MS6</span>
              </div>
              <h1 className="text-5xl font-bold text-gray-900 mb-4">
                
                {t('auth.welcome')}
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
                La plataforma de redes sociales más avanzada del mundo. Conecta, comparte y descubre contenido increíble con nuestra comunidad global.
              </p>
              <button
                onClick={() => setShowAuthModal(true)}
                className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-8 py-4 rounded-full text-lg font-medium hover:shadow-xl transition-all transform hover:scale-105"
              >
                {t('auth.register')}
              </button>
            </div>
            
            <div className="grid md:grid-cols-4 gap-8 mt-16">
              <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center mb-4 mx-auto">
                  <Users className="text-emerald-600" size={24} />
                </div>
                <h3 className="text-lg font-semibold mb-2">Comunidades Globales</h3>
                <p className="text-gray-600">Únete a comunidades de todo el mundo y conecta con personas que comparten tus intereses.</p>
              </div>
              
              <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4 mx-auto">
                  <Play className="text-red-600" size={24} />
                </div>
                <h3 className="text-lg font-semibold mb-2">Videos Avanzados</h3>
                <p className="text-gray-600">Crea y comparte videos con herramientas profesionales y funciones de IA integradas.</p>
              </div>
              
              <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-4 mx-auto">
                  <Sparkles className="text-purple-600" size={24} />
                </div>
                <h3 className="text-lg font-semibold mb-2">IA 4K Enhancement</h3>
                <p className="text-gray-600">Mejora tus fotos a resolución 4K usando nuestra tecnología de inteligencia artificial.</p>
              </div>
              
              <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center mb-4 mx-auto">
                  <MessageCircle className="text-emerald-600" size={24} />
                </div>
                <h3 className="text-lg font-semibold mb-2">Mensajería Avanzada</h3>
                <p className="text-gray-600">Sistema de mensajería en tiempo real con funciones avanzadas de comunicación.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <CreatePostModal 
        isOpen={showCreatePost}
        onClose={() => setShowCreatePost(false)}
        onCreatePost={handleCreatePost}
      />
      <CreateVideoModal 
        isOpen={showCreateVideo}
        onClose={() => setShowCreateVideo(false)}
        onCreateVideo={handleCreateVideo}
      />
      <AIEnhanceModal 
        isOpen={showAIEnhance}
        onClose={() => setShowAIEnhance(false)}
      />
      <AuthModal 
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onLogin={handleLogin}
        onRegister={handleRegister}
      />
      
      <div className="pt-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex gap-8">
          <div className="flex-1 max-w-2xl">
            {currentView === 'videos' ? (
              <VideoSection 
                onCreateVideo={handleCreateVideoClick}
                isAuthenticated={isAuthenticated}
              />
            ) : (
              <>
                <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
                  <div className="flex items-center space-x-4 mb-4">
                    <img 
                      src={currentUser?.avatar} 
                      alt={currentUser?.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <button
                      onClick={handleCreatePostClick}
                      className="flex-1 bg-gray-100 hover:bg-gray-200 text-left px-6 py-3 rounded-full text-gray-600 transition-colors"
                    >
                      {t('post.whatsOnMind')}
                    </button>
                    <button
                      onClick={handleCreatePostClick}
                      className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white p-3 rounded-full hover:shadow-lg transition-all"
                    >
                      <Plus size={20} />
                    </button>
                  </div>
                  
                  <div className="flex justify-between items-center pt-4 border-t border-gray-100">
                    <button
                      onClick={handleCreateVideoClick}
                      className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-full transition-all"
                    >
                      <Play size={18} />
                      <span className="font-medium">Video</span>
                    </button>
                    
                    <button
                      onClick={handleAIEnhanceClick}
                      className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-purple-600 hover:bg-purple-50 rounded-full transition-all"
                    >
                      <Sparkles size={18} />
                      <span className="font-medium">AI 4K</span>
                    </button>
                  </div>
                </div>

                <div className="space-y-6">
                  {posts.map(post => (
                    <PostCard 
                      key={post.id} 
                      post={post} 
                      onLike={handleLike}
                      onComment={handleComment}
                      onShare={handleShare}
                    />
                  ))}
                </div>
              </>
            )}
          </div>

          <Sidebar />
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-lg border-t border-gray-200 md:hidden">
        <div className="flex justify-around py-2">
          <button 
            onClick={() => setCurrentView('home')}
            className={`p-3 ${currentView === 'home' ? 'text-emerald-600' : 'text-gray-600'}`}
          >
            <Home size={24} />
          </button>
          <button 
            onClick={() => setCurrentView('videos')}
            className={`p-3 ${currentView === 'videos' ? 'text-emerald-600' : 'text-gray-600'}`}
          >
            <Play size={24} />
          </button>
          <button 
            onClick={() => setCurrentView('discover')}
            className={`p-3 ${currentView === 'discover' ? 'text-emerald-600' : 'text-gray-600'}`}
          >
            <Search size={24} />
          </button>
          <button 
            onClick={handleCreatePostClick}
            className="p-3 text-gray-600"
          >
            <Plus size={24} />
          </button>
          <button 
            onClick={handleAIEnhanceClick}
            className="p-3 text-gray-600"
          >
            <Sparkles size={24} />
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;