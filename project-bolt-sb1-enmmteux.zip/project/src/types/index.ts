export interface User {
  id: string;
  name: string;
  username: string;
  avatar: string;
  verified: boolean;
  bio?: string;
  followers: number;
  following: number;
  email?: string;
  firstName?: string;
  lastName?: string;
  gender?: 'male' | 'female' | 'other' | 'prefer-not-to-say';
  age?: number;
}

export interface Post {
  id: string;
  user: User;
  content: string;
  image?: string;
  video?: string;
  timestamp: string;
  likes: number;
  comments: Comment[];
  shares: number;
  isLiked: boolean;
  isShared: boolean;
  type: 'text' | 'image' | 'video';
}

export interface Video {
  id: string;
  user: User;
  title: string;
  description: string;
  videoUrl: string;
  thumbnail: string;
  duration: string;
  views: number;
  likes: number;
  timestamp: string;
  isLiked: boolean;
  tags: string[];
}

export interface Comment {
  id: string;
  user: User;
  content: string;
  timestamp: string;
  likes: number;
  isLiked: boolean;
}

export interface TrendingTopic {
  topic: string;
  posts: string;
  growth: number;
}

export interface Community {
  id: string;
  name: string;
  description: string;
  members: number;
  icon: string;
  color: string;
}

export interface AuthUser {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  gender: 'male' | 'female' | 'other' | 'prefer-not-to-say';
  age: number;
}

export interface AIEnhancement {
  id: string;
  originalImage: string;
  enhancedImage: string;
  status: 'processing' | 'completed' | 'failed';
  timestamp: string;
  userId: string;
}

export type Language = 'en' | 'es' | 'fr' | 'de' | 'it' | 'pt' | 'ru' | 'zh' | 'ja' | 'ko' | 'ar';