import React, { useState } from 'react';
import { X, Image, Video, MapPin, Smile } from 'lucide-react';
import { useLanguage } from '../hooks/useLanguage';

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreatePost: (content: string, image?: string) => void;
}

export const CreatePostModal: React.FC<CreatePostModalProps> = ({ isOpen, onClose, onCreatePost }) => {
  const { t } = useLanguage();
  const [content, setContent] = useState('');
  const [selectedImage, setSelectedImage] = useState<string>('');

  const handleSubmit = () => {
    if (content.trim()) {
      onCreatePost(content, selectedImage || undefined);
      setContent('');
      setSelectedImage('');
      onClose();
    }
  };

  const sampleImages = [
    'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=600',
    'https://images.pexels.com/photos/1287145/pexels-photo-1287145.jpeg?auto=compress&cs=tinysrgb&w=600',
    'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=600',
    'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=600'
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">{t('post.create')}</h3>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors p-1"
            >
              <X size={20} />
            </button>
          </div>
        </div>
        
        <div className="p-6 max-h-[calc(90vh-140px)] overflow-y-auto">
          <div className="flex items-start space-x-4 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-600 to-teal-600 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-sm">U</span>
            </div>
            <div>
              <h4 className="font-semibold">{t('nav.profile')}</h4>
              <p className="text-sm text-gray-500">{t('post.public')}</p>
            </div>
          </div>
          
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={t('post.whatsOnMind')}
            className="w-full p-4 border border-gray-200 rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            rows={4}
          />

          {selectedImage && (
            <div className="mt-4 relative">
              <img src={selectedImage} alt="Selected" className="w-full h-48 object-cover rounded-xl" />
              <button
                onClick={() => setSelectedImage('')}
                className="absolute top-2 right-2 bg-black/50 text-white p-1 rounded-full hover:bg-black/70 transition-colors"
              >
                <X size={16} />
              </button>
            </div>
          )}

          <div className="mt-4">
            <p className="text-sm font-medium text-gray-700 mb-2">Sample Images:</p>
            <div className="grid grid-cols-4 gap-2">
              {sampleImages.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(image)}
                  className={`relative rounded-lg overflow-hidden hover:opacity-80 transition-opacity ${
                    selectedImage === image ? 'ring-2 ring-emerald-500' : ''
                  }`}
                >
                  <img src={image} alt={`Sample ${index + 1}`} className="w-full h-16 object-cover" />
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-gray-200">
          <div className="flex justify-between items-center">
            <div className="flex space-x-4">
              <button className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-full transition-all">
                <Image size={20} />
              </button>
              <button className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-full transition-all">
                <Video size={20} />
              </button>
              <button className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-full transition-all">
                <MapPin size={20} />
              </button>
              <button className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-full transition-all">
                <Smile size={20} />
              </button>
            </div>
            <button
              onClick={handleSubmit}
              disabled={!content.trim()}
              className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-6 py-2 rounded-full font-medium hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {t('post.post')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};