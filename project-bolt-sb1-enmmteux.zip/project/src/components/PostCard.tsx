import React, { useState } from 'react';
import { Heart, MessageSquare, Share, MoreHorizontal } from 'lucide-react';
import { Post, Comment } from '../types';
import { useLanguage } from '../hooks/useLanguage';
import { formatTimeAgo, generateId } from '../utils/timeUtils';

interface PostCardProps {
  post: Post;
  onLike: (postId: string) => void;
  onComment: (postId: string, content: string) => void;
  onShare: (postId: string) => void;
}

export const PostCard: React.FC<PostCardProps> = ({ post, onLike, onComment, onShare }) => {
  const { t } = useLanguage();
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');

  const handleComment = () => {
    if (commentText.trim()) {
      onComment(post.id, commentText);
      setCommentText('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleComment();
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-all duration-300">
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <img src={post.user.avatar} alt={post.user.name} className="w-10 h-10 rounded-full object-cover" />
            <div>
              <div className="flex items-center space-x-2">
                <h4 className="font-semibold text-gray-900">{post.user.name}</h4>
                {post.user.verified && <span className="text-emerald-600">✓</span>}
              </div>
              <p className="text-sm text-gray-500">
                @{post.user.username} • {formatTimeAgo(post.timestamp, t)}
              </p>
            </div>
          </div>
          <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-all">
            <MoreHorizontal size={18} />
          </button>
        </div>

        <p className="text-gray-800 mb-4 leading-relaxed whitespace-pre-wrap">{post.content}</p>
        
        {post.image && (
          <img src={post.image} alt="Post content" className="w-full h-64 object-cover rounded-xl mb-4" />
        )}

        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <button
            onClick={() => onLike(post.id)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-all ${
              post.isLiked
                ? 'text-red-500 bg-red-50 hover:bg-red-100'
                : 'text-gray-600 hover:text-red-500 hover:bg-red-50'
            }`}
          >
            <Heart size={18} className={post.isLiked ? 'fill-current' : ''} />
            <span className="font-medium">{post.likes}</span>
          </button>
          
          <button
            onClick={() => setShowComments(!showComments)}
            className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-full transition-all"
          >
            <MessageSquare size={18} />
            <span className="font-medium">{post.comments.length}</span>
          </button>
          
          <button
            onClick={() => onShare(post.id)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-all ${
              post.isShared
                ? 'text-blue-500 bg-blue-50 hover:bg-blue-100'
                : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
            }`}
          >
            <Share size={18} />
            <span className="font-medium">{post.shares}</span>
          </button>
        </div>

        {showComments && (
          <div className="mt-4 pt-4 border-t border-gray-100">
            <div className="space-y-3 mb-4">
              {post.comments.map((comment) => (
                <div key={comment.id} className="flex items-start space-x-3">
                  <img src={comment.user.avatar} alt={comment.user.name} className="w-8 h-8 rounded-full object-cover" />
                  <div className="flex-1 bg-gray-50 rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="font-medium text-sm">{comment.user.name}</span>
                      <span className="text-xs text-gray-500">{formatTimeAgo(comment.timestamp, t)}</span>
                    </div>
                    <p className="text-sm text-gray-800">{comment.content}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-emerald-600 to-teal-600 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">U</span>
              </div>
              <div className="flex-1 flex items-center space-x-2">
                <input
                  type="text"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder={t('post.writeComment')}
                  className="flex-1 px-4 py-2 bg-gray-100 border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                />
                <button
                  onClick={handleComment}
                  disabled={!commentText.trim()}
                  className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-4 py-2 rounded-full font-medium hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {t('post.addComment')}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};