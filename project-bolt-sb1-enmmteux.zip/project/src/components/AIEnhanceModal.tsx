import React, { useState } from 'react';
import { X, Upload, Sparkles, Download, Zap, Image as ImageIcon } from 'lucide-react';
import { useLanguage } from '../hooks/useLanguage';

interface AIEnhanceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AIEnhanceModal: React.FC<AIEnhanceModalProps> = ({ isOpen, onClose }) => {
  const { t } = useLanguage();
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [enhancedImage, setEnhancedImage] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);

  const sampleImages = [
    'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/1287145/pexels-photo-1287145.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=400'
  ];

  const handleEnhance = async () => {
    if (!selectedImage) return;
    
    setIsProcessing(true);
    setProcessingProgress(0);
    
    // Simular proceso de IA
    const interval = setInterval(() => {
      setProcessingProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsProcessing(false);
          // Simular imagen mejorada (en realidad sería la misma pero con parámetros de mayor calidad)
          setEnhancedImage(selectedImage.replace('w=400', 'w=1200'));
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  const handleReset = () => {
    setSelectedImage('');
    setEnhancedImage('');
    setIsProcessing(false);
    setProcessingProgress(0);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center">
                <Sparkles className="text-white" size={20} />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">{t('ai.enhance4k')}</h3>
                <p className="text-sm text-gray-500">{t('ai.enhanceDescription')}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors p-1"
            >
              <X size={20} />
            </button>
          </div>
        </div>
        
        <div className="p-6 max-h-[calc(90vh-140px)] overflow-y-auto">
          {!selectedImage ? (
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-purple-100 to-pink-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <ImageIcon className="text-purple-600" size={32} />
                </div>
                <h4 className="text-lg font-semibold mb-2">{t('ai.selectImage')}</h4>
                <p className="text-gray-600">{t('ai.selectImageDescription')}</p>
              </div>

              <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-purple-400 transition-colors">
                <Upload className="mx-auto text-gray-400 mb-4" size={48} />
                <p className="text-lg font-medium text-gray-700 mb-2">{t('ai.uploadImage')}</p>
                <p className="text-sm text-gray-500 mb-4">{t('ai.supportedFormats')}</p>
                <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-2 rounded-full font-medium hover:shadow-lg transition-all">
                  {t('ai.chooseFile')}
                </button>
              </div>

              <div className="space-y-4">
                <h5 className="font-medium text-gray-700">{t('ai.sampleImages')}</h5>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {sampleImages.map((image, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedImage(image)}
                      className="relative rounded-xl overflow-hidden hover:scale-105 transition-transform group"
                    >
                      <img src={image} alt={`Sample ${index + 1}`} className="w-full h-24 object-cover" />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                        <Sparkles className="text-white opacity-0 group-hover:opacity-100 transition-opacity" size={20} />
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900 flex items-center">
                    <ImageIcon className="mr-2 text-gray-600" size={20} />
                    {t('ai.original')}
                  </h4>
                  <div className="relative rounded-xl overflow-hidden bg-gray-100">
                    <img src={selectedImage} alt="Original" className="w-full h-64 object-cover" />
                    <div className="absolute top-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
                      {t('ai.standardQuality')}
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900 flex items-center">
                    <Sparkles className="mr-2 text-purple-600" size={20} />
                    {t('ai.enhanced4k')}
                  </h4>
                  <div className="relative rounded-xl overflow-hidden bg-gray-100">
                    {isProcessing ? (
                      <div className="w-full h-64 flex items-center justify-center bg-gradient-to-br from-purple-50 to-pink-50">
                        <div className="text-center">
                          <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                            <Zap className="text-white" size={24} />
                          </div>
                          <p className="font-medium text-gray-700 mb-2">{t('ai.processing')}</p>
                          <div className="w-48 bg-gray-200 rounded-full h-2 mx-auto">
                            <div 
                              className="bg-gradient-to-r from-purple-600 to-pink-600 h-2 rounded-full transition-all duration-300"
                              style={{ width: `${processingProgress}%` }}
                            ></div>
                          </div>
                          <p className="text-sm text-gray-500 mt-2">{processingProgress}%</p>
                        </div>
                      </div>
                    ) : enhancedImage ? (
                      <>
                        <img src={enhancedImage} alt="Enhanced" className="w-full h-64 object-cover" />
                        <div className="absolute top-2 right-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-2 py-1 rounded text-xs font-medium">
                          4K {t('ai.enhanced')}
                        </div>
                      </>
                    ) : (
                      <div className="w-full h-64 flex items-center justify-center bg-gray-50 border-2 border-dashed border-gray-300">
                        <div className="text-center text-gray-500">
                          <Sparkles size={32} className="mx-auto mb-2" />
                          <p>{t('ai.clickToEnhance')}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex justify-center space-x-4">
                {!enhancedImage && !isProcessing && (
                  <button
                    onClick={handleEnhance}
                    className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-3 rounded-full font-medium hover:shadow-lg transition-all flex items-center space-x-2"
                  >
                    <Sparkles size={20} />
                    <span>{t('ai.enhanceNow')}</span>
                  </button>
                )}
                
                {enhancedImage && (
                  <>
                    <button
                      onClick={handleReset}
                      className="bg-gray-100 text-gray-700 px-6 py-3 rounded-full font-medium hover:bg-gray-200 transition-all"
                    >
                      {t('ai.tryAnother')}
                    </button>
                    <button className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-6 py-3 rounded-full font-medium hover:shadow-lg transition-all flex items-center space-x-2">
                      <Download size={20} />
                      <span>{t('ai.download4k')}</span>
                    </button>
                  </>
                )}
              </div>

              {enhancedImage && (
                <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center">
                      <Sparkles className="text-white" size={16} />
                    </div>
                    <div>
                      <h5 className="font-semibold text-gray-900">{t('ai.enhancementComplete')}</h5>
                      <p className="text-sm text-gray-600">{t('ai.qualityImproved')}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};