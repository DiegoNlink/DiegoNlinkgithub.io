import React, { useState } from 'react';
import { X, Video, Upload, Sparkles, Play, Pause, Volume2 } from 'lucide-react';
import { useLanguage } from '../hooks/useLanguage';

interface CreateVideoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateVideo: (title: string, description: string, videoUrl: string, tags: string[]) => void;
}

export const CreateVideoModal: React.FC<CreateVideoModalProps> = ({ isOpen, onClose, onCreateVideo }) => {
  const { t } = useLanguage();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedVideo, setSelectedVideo] = useState<string>('');
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);

  const sampleVideos = [
    {
      url: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4',
      thumbnail: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=300',
      title: 'Proyecto Tecnológico'
    },
    {
      url: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_2mb.mp4',
      thumbnail: 'https://images.pexels.com/photos/1287145/pexels-photo-1287145.jpeg?auto=compress&cs=tinysrgb&w=300',
      title: 'Tutorial Creativo'
    },
    {
      url: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_5mb.mp4',
      thumbnail: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=300',
      title: 'Presentación Profesional'
    }
  ];

  const handleSubmit = () => {
    if (title.trim() && description.trim() && selectedVideo) {
      onCreateVideo(title, description, selectedVideo, tags);
      setTitle('');
      setDescription('');
      setSelectedVideo('');
      setTags([]);
      setTagInput('');
      onClose();
    }
  };

  const addTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim()) && tags.length < 5) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addTag();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-pink-600 rounded-xl flex items-center justify-center">
                <Video className="text-white" size={20} />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">{t('video.create')}</h3>
                <p className="text-sm text-gray-500">{t('video.createDescription')}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors p-1"
            >
              <X size={20} />
            </button>
          </div>
        </div>
        
        <div className="p-6 max-h-[calc(90vh-140px)] overflow-y-auto">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Selección de video */}
            <div className="space-y-4">
              <h4 className="font-semibold text-gray-900">{t('video.selectVideo')}</h4>
              
              {!selectedVideo ? (
                <div className="space-y-4">
                  <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-red-400 transition-colors">
                    <Upload className="mx-auto text-gray-400 mb-3" size={40} />
                    <p className="font-medium text-gray-700 mb-1">{t('video.uploadVideo')}</p>
                    <p className="text-sm text-gray-500 mb-3">{t('video.supportedFormats')}</p>
                    <button className="bg-gradient-to-r from-red-600 to-pink-600 text-white px-4 py-2 rounded-full font-medium hover:shadow-lg transition-all">
                      {t('video.chooseFile')}
                    </button>
                  </div>

                  <div className="space-y-3">
                    <p className="text-sm font-medium text-gray-700">{t('video.sampleVideos')}</p>
                    <div className="grid gap-3">
                      {sampleVideos.map((video, index) => (
                        <button
                          key={index}
                          onClick={() => setSelectedVideo(video.url)}
                          className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:border-red-300 hover:bg-red-50 transition-all group"
                        >
                          <div className="relative">
                            <img src={video.thumbnail} alt={video.title} className="w-16 h-12 object-cover rounded" />
                            <div className="absolute inset-0 bg-black/20 rounded flex items-center justify-center">
                              <Play className="text-white" size={16} />
                            </div>
                          </div>
                          <div className="flex-1 text-left">
                            <p className="font-medium text-gray-900 group-hover:text-red-600">{video.title}</p>
                            <p className="text-sm text-gray-500">Video de muestra</p>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="relative rounded-xl overflow-hidden bg-black">
                    <video 
                      src={selectedVideo}
                      className="w-full h-48 object-cover"
                      controls={false}
                      muted
                    />
                    <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                      <button
                        onClick={() => setIsPlaying(!isPlaying)}
                        className="w-12 h-12 bg-white/90 rounded-full flex items-center justify-center hover:scale-110 transition-transform"
                      >
                        {isPlaying ? <Pause className="text-gray-800" size={20} /> : <Play className="text-gray-800 ml-1" size={20} />}
                      </button>
                    </div>
                    <div className="absolute bottom-2 right-2 flex space-x-2">
                      <button className="p-2 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors">
                        <Volume2 size={16} />
                      </button>
                    </div>
                  </div>
                  <button
                    onClick={() => setSelectedVideo('')}
                    className="w-full py-2 text-gray-600 hover:text-red-600 transition-colors"
                  >
                    {t('video.changeVideo')}
                  </button>
                </div>
              )}
            </div>

            {/* Información del video */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('video.title')}
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder={t('video.titlePlaceholder')}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  maxLength={100}
                />
                <p className="text-xs text-gray-500 mt-1">{title.length}/100</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('video.description')}
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={t('video.descriptionPlaceholder')}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  rows={4}
                  maxLength={500}
                />
                <p className="text-xs text-gray-500 mt-1">{description.length}/500</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('video.tags')} ({tags.length}/5)
                </label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {tags.map((tag, index) => (
                    <span
                      key={index}
                      className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm flex items-center space-x-1"
                    >
                      <span>{tag}</span>
                      <button
                        onClick={() => removeTag(tag)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <X size={14} />
                      </button>
                    </span>
                  ))}
                </div>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={tagInput}
                    onChange={(e) => setTagInput(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder={t('video.addTag')}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    disabled={tags.length >= 5}
                  />
                  <button
                    onClick={addTag}
                    disabled={!tagInput.trim() || tags.length >= 5}
                    className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {t('video.add')}
                  </button>
                </div>
              </div>

              <div className="bg-gradient-to-r from-red-50 to-pink-50 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Sparkles className="text-red-600" size={20} />
                  <h5 className="font-semibold text-gray-900">{t('video.aiFeatures')}</h5>
                </div>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• {t('video.autoThumbnail')}</li>
                  <li>• {t('video.autoSubtitles')}</li>
                  <li>• {t('video.qualityOptimization')}</li>
                  <li>• {t('video.smartTags')}</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-gray-200">
          <div className="flex justify-end space-x-4">
            <button
              onClick={onClose}
              className="px-6 py-2 text-gray-600 hover:text-gray-800 transition-colors"
            >
              {t('video.cancel')}
            </button>
            <button
              onClick={handleSubmit}
              disabled={!title.trim() || !description.trim() || !selectedVideo}
              className="bg-gradient-to-r from-red-600 to-pink-600 text-white px-8 py-2 rounded-full font-medium hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
            >
              <Video size={18} />
              <span>{t('video.publish')}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};