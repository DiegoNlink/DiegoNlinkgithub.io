import React, { useState } from 'react';
import { Play, Heart, MessageSquare, Share, Eye, Clock, Sparkles } from 'lucide-react';
import { Video } from '../types';
import { useLanguage } from '../hooks/useLanguage';
import { formatTimeAgo } from '../utils/timeUtils';

interface VideoSectionProps {
  onCreateVideo: () => void;
  isAuthenticated: boolean;
}

export const VideoSection: React.FC<VideoSectionProps> = ({ onCreateVideo, isAuthenticated }) => {
  const { t } = useLanguage();
  
  const [videos] = useState<Video[]>([
    {
      id: '1',
      user: {
        id: '1',
        name: 'Alex Rodriguez',
        username: 'alexr',
        avatar: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=150',
        verified: true,
        followers: 1250,
        following: 890
      },
      title: 'Mi nuevo proyecto con IA - Increíble resultado!',
      description: 'Les muestro cómo la IA puede transformar completamente nuestros proyectos. ¡Los resultados son impresionantes!',
      videoUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4',
      thumbnail: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=600',
      duration: '2:45',
      views: 15420,
      likes: 892,
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
      isLiked: false,
      tags: ['#IA', '#Tecnología', '#Innovación']
    },
    {
      id: '2',
      user: {
        id: '2',
        name: 'Sarah Chen',
        username: 'sarahc',
        avatar: 'https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=150',
        verified: false,
        followers: 500,
        following: 300
      },
      title: 'Tutorial: Cómo mejorar fotos con IA a 4K',
      description: 'Paso a paso para transformar tus fotos usando nuestra IA integrada. ¡Resultados profesionales en segundos!',
      videoUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_2mb.mp4',
      thumbnail: 'https://images.pexels.com/photos/1287145/pexels-photo-1287145.jpeg?auto=compress&cs=tinysrgb&w=600',
      duration: '5:12',
      views: 28750,
      likes: 1456,
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
      isLiked: true,
      tags: ['#Tutorial', '#IA', '#4K', '#Fotografía']
    },
    {
      id: '3',
      user: {
        id: '3',
        name: 'Marcus Thompson',
        username: 'marcust',
        avatar: 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=150',
        verified: true,
        followers: 2100,
        following: 450
      },
      title: 'El futuro de las redes sociales está aquí',
      description: 'Exploramos las nuevas funcionalidades de MS6 y cómo están revolucionando la forma en que compartimos contenido.',
      videoUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_5mb.mp4',
      thumbnail: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=600',
      duration: '8:30',
      views: 45200,
      likes: 2340,
      timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
      isLiked: false,
      tags: ['#MS6', '#Futuro', '#RedesSociales']
    }
  ]);

  const VideoCard: React.FC<{ video: Video }> = ({ video }) => (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-lg transition-all duration-300 group">
      <div className="relative">
        <img 
          src={video.thumbnail} 
          alt={video.title}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors duration-300" />
        <button className="absolute inset-0 flex items-center justify-center">
          <div className="w-16 h-16 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
            <Play size={24} className="text-emerald-600 ml-1" />
          </div>
        </button>
        <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-sm font-medium">
          {video.duration}
        </div>
        <div className="absolute top-2 left-2 flex gap-1">
          {video.tags.slice(0, 2).map((tag, index) => (
            <span key={index} className="bg-emerald-600/90 text-white px-2 py-1 rounded-full text-xs font-medium">
              {tag}
            </span>
          ))}
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex items-start space-x-3 mb-3">
          <img 
            src={video.user.avatar} 
            alt={video.user.name}
            className="w-10 h-10 rounded-full object-cover"
          />
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900 line-clamp-2 mb-1">
              {video.title}
            </h3>
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <span>{video.user.name}</span>
              {video.user.verified && <span className="text-emerald-600">✓</span>}
            </div>
          </div>
        </div>
        
        <p className="text-sm text-gray-600 line-clamp-2 mb-3">
          {video.description}
        </p>
        
        <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Eye size={16} />
              <span>{video.views.toLocaleString()}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Clock size={16} />
              <span>{formatTimeAgo(video.timestamp, t)}</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-between pt-3 border-t border-gray-100">
          <button className={`flex items-center space-x-2 px-3 py-2 rounded-full transition-all ${
            video.isLiked 
              ? 'text-red-500 bg-red-50 hover:bg-red-100' 
              : 'text-gray-600 hover:text-red-500 hover:bg-red-50'
          }`}>
            <Heart size={18} className={video.isLiked ? 'fill-current' : ''} />
            <span className="font-medium">{video.likes.toLocaleString()}</span>
          </button>
          
          <button className="flex items-center space-x-2 px-3 py-2 text-gray-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-full transition-all">
            <MessageSquare size={18} />
            <span className="font-medium">Comentar</span>
          </button>
          
          <button className="flex items-center space-x-2 px-3 py-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-all">
            <Share size={18} />
            <span className="font-medium">Compartir</span>
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header con botón de crear video */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 flex items-center">
              <Play className="mr-3 text-emerald-600" size={28} />
              {t('video.section')}
            </h2>
            <p className="text-gray-600 mt-1">{t('video.description')}</p>
          </div>
          <button
            onClick={onCreateVideo}
            disabled={!isAuthenticated}
            className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-6 py-3 rounded-full font-medium hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
          >
            <Sparkles size={20} />
            <span>{t('video.create')}</span>
          </button>
        </div>
        
        {/* Estadísticas */}
        <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-100">
          <div className="text-center">
            <div className="text-2xl font-bold text-emerald-600">89.2K</div>
            <div className="text-sm text-gray-500">{t('video.totalViews')}</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-emerald-600">4.7K</div>
            <div className="text-sm text-gray-500">{t('video.totalVideos')}</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-emerald-600">1.2K</div>
            <div className="text-sm text-gray-500">{t('video.creators')}</div>
          </div>
        </div>
      </div>

      {/* Grid de videos */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {videos.map(video => (
          <VideoCard key={video.id} video={video} />
        ))}
      </div>
    </div>
  );
};