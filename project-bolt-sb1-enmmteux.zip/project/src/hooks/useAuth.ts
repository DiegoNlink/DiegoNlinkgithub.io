import { useState, useEffect } from 'react';
import { User, AuthUser } from '../types';
import { generateId } from '../utils/timeUtils';

export const useAuth = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('ms6-user');
    return saved ? JSON.parse(saved) : null;
  });
  
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return !!localStorage.getItem('ms6-user');
  });

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('ms6-user', JSON.stringify(currentUser));
      setIsAuthenticated(true);
    } else {
      localStorage.removeItem('ms6-user');
      setIsAuthenticated(false);
    }
  }, [currentUser]);

  const login = (email: string, password: string): boolean => {
    // Simulate login validation
    const users = JSON.parse(localStorage.getItem('ms6-registered-users') || '[]');
    const user = users.find((u: any) => u.email === email && u.password === password);
    
    if (user) {
      const loggedInUser: User = {
        id: user.id,
        name: `${user.firstName} ${user.lastName}`,
        username: user.email.split('@')[0],
        avatar: `https://images.pexels.com/photos/${user.gender === 'male' ? '1040880' : '1181690'}/pexels-photo-${user.gender === 'male' ? '1040880' : '1181690'}.jpeg?auto=compress&cs=tinysrgb&w=150`,
        verified: false,
        followers: 0,
        following: 0,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        gender: user.gender,
        age: user.age
      };
      setCurrentUser(loggedInUser);
      return true;
    }
    return false;
  };

  const register = (userData: AuthUser): boolean => {
    // Check if email already exists
    const users = JSON.parse(localStorage.getItem('ms6-registered-users') || '[]');
    const existingUser = users.find((u: any) => u.email === userData.email);
    
    if (existingUser) {
      return false; // Email already exists
    }

    // Add new user
    const newUser = {
      ...userData,
      id: generateId()
    };
    
    users.push(newUser);
    localStorage.setItem('ms6-registered-users', JSON.stringify(users));
    
    // Auto login after registration
    login(userData.email, userData.password);
    return true;
  };

  const logout = () => {
    setCurrentUser(null);
  };

  return {
    currentUser,
    isAuthenticated,
    login,
    register,
    logout
  };
};