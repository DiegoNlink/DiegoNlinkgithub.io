import { useState, useEffect } from 'react';
import { Language } from '../types';
import { translations } from '../utils/translations';

export const useLanguage = () => {
  const [currentLanguage, setCurrentLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('ms6-language');
    return (saved as Language) || 'en';
  });

  useEffect(() => {
    localStorage.setItem('ms6-language', currentLanguage);
    document.documentElement.lang = currentLanguage;
  }, [currentLanguage]);

  const t = (key: string): string => {
    const keys = key.split('.');
    let value: any = translations[currentLanguage];
    
    for (const k of keys) {
      value = value?.[k];
    }
    
    return value || key;
  };

  const changeLanguage = (language: Language) => {
    setCurrentLanguage(language);
  };

  return { currentLanguage, t, changeLanguage };
};